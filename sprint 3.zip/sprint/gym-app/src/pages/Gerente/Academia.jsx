import React from 'react';

function GerenteAcademia() {
  return (
    <div className="gym-management">
      <h1>Gerenciar Academia</h1>
      <form>
        <input type="text" placeholder="Nome da Academia" />
        <textarea placeholder="Descrição"></textarea>
        <button type="submit">Salvar</button>
      </form>
    </div>
  );
}

export default GerenteAcademia;

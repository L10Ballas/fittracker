import React from 'react';

function GerenteEstatisticas() {
  return (
    <div className="statistics">
      <h1>Estatísticas do Anúncio</h1>
      <p>Total de Visualizações: 1000</p>
      <p>Total de Cliques: 100</p>
    </div>
  );
}

export default GerenteEstatisticas;

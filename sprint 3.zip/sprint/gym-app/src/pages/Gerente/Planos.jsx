import React from 'react';

function GerentePlanos() {
  return (
    <div className="plans">
      <h1>Gerenciar Planos</h1>
      <form>
        <input type="text" placeholder="Nome do Plano" />
        <input type="text" placeholder="Preço" />
        <button type="submit">Salvar</button>
      </form>
    </div>
  );
}

export default GerentePlanos;

import React from 'react';

function GerentePerfil() {
  return (
    <div className="profile-container">
      <h1>Perfil do Gerente</h1>
      <p>Nome: Gerente Exemplo</p>
      <p>Email: gerente@example.com</p>
    </div>
  );
}

export default GerentePerfil;

import React from 'react';

function ClientePerfil() {
  return (
    <div className="profile-container">
      <h1>Perfil do Cliente</h1>
      <p>Nome: Cliente Exemplo</p>
      <p>Email: cliente@example.com</p>
    </div>
  );
}

export default ClientePerfil;

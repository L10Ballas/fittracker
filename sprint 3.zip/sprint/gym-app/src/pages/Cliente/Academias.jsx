import React from 'react';

function ClienteAcademias() {
  return (
    <div className="gyms-list">
      <h1>Academias</h1>
      <ul>
        <li>Academia 1</li>
        <li>Academia 2</li>
        <li>Academia 3</li>
      </ul>
    </div>
  );
}

export default ClienteAcademias;

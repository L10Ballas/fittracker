import React from 'react';

function ClienteLogin() {
  return (
    <div className="login-container">
      <h1>Login Cliente</h1>
      <form>
        <input type="email" placeholder="Email" />
        <input type="password" placeholder="Senha" />
        <button type="submit">Entrar</button>
      </form>
    </div>
  );
}

export default ClienteLogin;

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import ClienteLogin from './pages/Cliente/Login';
import ClientePerfil from './pages/Cliente/Perfil';
import ClienteAcademias from './pages/Cliente/Academias';
import GerenteLogin from './pages/Gerente/Login';
import GerentePerfil from './pages/Gerente/Perfil';
import GerenteAcademia from './pages/Gerente/Academia';
import GerenteEstatisticas from './pages/Gerente/Estatisticas';
import GerentePlanos from './pages/Gerente/Planos';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/cliente/login" element={<ClienteLogin />} />
        <Route path="/cliente/perfil" element={<ClientePerfil />} />
        <Route path="/cliente/academias" element={<ClienteAcademias />} />
        <Route path="/gerente/login" element={<GerenteLogin />} />
        <Route path="/gerente/perfil" element={<GerentePerfil />} />
        <Route path="/gerente/academia" element={<GerenteAcademia />} />
        <Route path="/gerente/estatisticas" element={<GerenteEstatisticas />} />
        <Route path="/gerente/planos" element={<GerentePlanos />} />
      </Routes>
    </div>
  );
}

export default App;
